import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QGridLayout, QVBoxLayout, QHBoxLayout, QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont, QIcon

GRID_WIDTH = 15
GRID_HEIGHT = 9
map_data = [[0] * GRID_WIDTH for _ in range(GRID_HEIGHT)]
current_value = 0

class MapEditor(QWidget):
    def __init__(SELF):
        super().__init__()
        SELF.init_ui()
        SELF.tile_icons = {
            0:  "#ecf0f1",  # \\ Floor
            1: "Assets/Wall_2.png",  # \\ Wall
            2: "Assets/Object_1.png",  # \\ Static Object
            3: "Assets/Coin_2.png",  # \\ Coin
            4: "Assets/Key_1.png",  # \\ Key
            5: "Assets/Door_5.png",  # \\ Door
            6: "Assets/MovingObject_1.png",  # \\ Moving Object
        }

    def init_ui(SELF):
        SELF.setWindowTitle('Tile Map Editor For')
        SELF.setGeometry(100, 100, 800, 600)
        SELF.setStyleSheet("background-color: #bd8958; font-family: Arial, sans-serif;")

        Main_Layout = QVBoxLayout(SELF)

        # \\ Create the grid layout \\ 
        Grid_Layout = QGridLayout()
        Grid_Layout.setSpacing(0)  

        SELF.buttons = []
        for row in range(GRID_HEIGHT):
            row_buttons = []
            for col in range(GRID_WIDTH):
                button = QPushButton('', SELF)
                button.setFixedSize(60, 60)
                button.setStyleSheet('border: 1px solid black; border-radius: 8px;')
                button.clicked.connect(lambda checked, r=row, c=col: SELF.update_cell(r, c))
                row_buttons.append(button)
                Grid_Layout.addWidget(button, row, col)
            SELF.buttons.append(row_buttons)

        Main_Layout.addLayout(Grid_Layout)

        Button_Frame = QHBoxLayout()
        Button_Frame.setSpacing(10)
        values = [("Floor", 0), ("Wall", 1), ("Object", 2), ("Coin", 3), ("Key", 4), ("Door", 5), ("Moving_Object", 6)]
        for label, value in values:
            button = QPushButton(label, SELF)
            button.setFixedSize(120, 50)  # \\ Increase button size to make room for more text
            button.setStyleSheet(
                '''
                background-color: #4a0602;
                color: lime;
                border: none;
                border-radius: 5px;
                font-weight: bold;
                padding: 10px;  # Adjusted padding to ensure text has enough space
                font-size: 14px; # Adjust font size
                text-align: center;  # Ensure text is centered
                '''
            )
            button.setCursor(Qt.PointingHandCursor)
            button.clicked.connect(lambda checked, v=value: SELF.set_value(v))
            Button_Frame.addWidget(button)

        Main_Layout.addLayout(Button_Frame)

        # Save and Load buttons
        Save_Button = QPushButton('Save Map', SELF)
        Save_Button.setFixedSize(120, 40)
        Save_Button.setStyleSheet(
                '''
                background-color: #4a0602;
                color: lime;
                border: none;
                border-radius: 5px;
                font-weight: bold;
                padding: 10px;  # Adjusted padding to ensure text has enough space
                font-size: 14px; # Adjust font size
                text-align: center;  # Ensure text is centered
                '''
        )
        Save_Button.setCursor(Qt.PointingHandCursor)
        Save_Button.clicked.connect(SELF.save_map)
        Main_Layout.addWidget(Save_Button)

        Load_Button = QPushButton('Load Map', SELF)
        Load_Button.setFixedSize(120, 40)
        Load_Button.setStyleSheet(
                '''
                background-color: #4a0602;
                color: lime;
                border: none;
                border-radius: 5px;
                font-weight: bold;
                padding: 10px;  # Adjusted padding to ensure text has enough space
                font-size: 14px; # Adjust font size
                text-align: center;  # Ensure text is centered
                '''
        )
        Load_Button.setCursor(Qt.PointingHandCursor)
        Load_Button.clicked.connect(SELF.load_map)
        Main_Layout.addWidget(Load_Button)

    def update_cell(SELF, row, col):
        map_data[row][col] = current_value
        SELF.update_button_color(row, col)

    def update_button_color(SELF, row, col):
        value = map_data[row][col]
        button = SELF.buttons[row][col]
        if value in SELF.tile_icons:
            button.setIcon(QIcon(SELF.tile_icons[value]))
            button.setIconSize(button.size())
        else:
            button.setIcon(QIcon())  # \\Clear the icon if no valid value is set

    def set_value(SELF, value):
        global current_value
        current_value = value

    def save_map(SELF):
        try:
            with open("saved_map.txt", "w") as file:
                for row in map_data:
                    file.write(f"[{', '.join(map(str, row))}],\n")
            QMessageBox.information(SELF, "Save", "Map saved successfully!", QMessageBox.Ok)
        except Exception as e:
            QMessageBox.critical(SELF, "Error", f"Failed to save map: {e}", QMessageBox.Ok)

    def load_map(SELF):
        try:
            with open("saved_map.txt", "r") as file:
                for row_num, line in enumerate(file.readlines()):
                    line = line.strip().strip(',')
                    row = list(map(int, line[1:-1].split(', ')))
                    map_data[row_num] = row
                    for col_num, value in enumerate(row):
                        SELF.update_button_color(row_num, col_num)
            QMessageBox.information(SELF, "Load", "Map loaded successfully!", QMessageBox.Ok)
        except Exception as e:
            QMessageBox.critical(SELF, "Error", f"Failed to load map: {e}", QMessageBox.Ok)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    editor = MapEditor()
    editor.show()
    sys.exit(app.exec_())
