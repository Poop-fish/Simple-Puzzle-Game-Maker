import pygame , random , itertools , time 
from Puzzle_Game_Maps import draw_map, Starting_Map, Map_1, map_2, map_3, map_4, map_5, map_6, map_7 ,map_8
from Puzzle_Game_Player import move_player, interact_with_tile
from Puzzle_Game_Particle_System import Particle , GenerateParticles , RenderParticles ,UpdateParticles
from Puzzle_Game_Screens import DisplayMessage

WIDTH, HEIGHT = 760, 460 #\\ 760, 460
TILE_SIZE = 50  #\\ 50
FPS = 30
BLACK = ("#000000")
WHITE = ("#e4ede4")
NEON_GREEN = ("#07ed0b")
YELLOW = ("#f0fc03")
BLUE = ("#051efc")
RED = ("#ff0000") 
GREY = ("#545454")
DEV_MODE = True

def CalculateStarRating(Inventory, TotalCoins, Deaths):
    if Inventory['coins'] == TotalCoins and Deaths == 0:
        return 3 # \\Perfect run
    elif Inventory['coins'] == TotalCoins:
        return 2 #\\All coins collected, but with deaths
    return 1 #\\Cleared without collecting all coins

def ResetGameState(Maps, CurrentMapIndex, Deaths):
    TileMap = Maps[CurrentMapIndex]()
    MovingObjects = []
    for Y, Row in enumerate(TileMap):
        for X, Tile in enumerate(Row):
            if Tile == 6:
                MovingObjects.append({"Pos": (X, Y), "Direction": (1, 0)})
    
    #\\Initialize Inventory with 'coins' and 'keys'//
    Inventory = {'coins': 0, 'keys': 0}
    return TileMap, (1, 1), Inventory, Deaths, MovingObjects

def UpdateMovingObjects(TileMap, MovingObjects, FrameCount):
    for Obj in MovingObjects:
        X, Y = Obj["Pos"]
        DX, DY = Obj["Direction"]
        if FrameCount % 20 == 0:
            NewX, NewY = X + DX, Y + DY
            if NewX < 0 or NewX >= len(TileMap[0]) or TileMap[Y][NewX] == 1:
                Obj["Direction"] = (-DX, DY)
                NewX = X
            if NewY < 0 or NewY >= len(TileMap) or TileMap[NewY][X] == 1:
                Obj["Direction"] = (DX, -DY)
                NewY = Y
            TileMap[Y][X] = 0
            TileMap[NewY][NewX] = 6 #\\Set what Tile is the moving tile
            Obj["Pos"] = (NewX, NewY)
    return TileMap

def RunPuzzleGame():
    pygame.init()
    SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Puzzle Game')
    Clock = pygame.time.Clock()
    Font = pygame.font.Font('Assets/PixelFont1.ttf', 30)

    # Load assets
    PlayerImage = pygame.image.load("assets/BossEyeball.png")
    PlayerImage = pygame.transform.scale(PlayerImage, (TILE_SIZE - 15, TILE_SIZE - 15))
    StarImage = pygame.image.load("assets/StartPNG_1.png")
    StarImage = pygame.transform.scale(StarImage, (80, 80))
    CoinIcon = pygame.image.load("assets/Coin_3.png")
    CoinIcon = pygame.transform.scale(CoinIcon, (30, 30)) # 24,24
    KeyIcon = pygame.image.load("assets/Key_1.png")
    KeyIcon = pygame.transform.scale(KeyIcon, (50, 50))
    SkullIcon = pygame.image.load("assets/Skull_1.png")
    SkullIcon = pygame.transform.scale(SkullIcon, (60, 60))

    #\\Initialize maps and variables\\
    Maps = [Starting_Map, Map_1, map_2, map_3, map_4, map_5, map_6, map_7, map_8]
    CurrentMapIndex = 0
    TileMap, PlayerPos, Inventory, Deaths, MovingObjects = ResetGameState(Maps, CurrentMapIndex, 0)
    TotalCoins = sum(Row.count(3) for Row in TileMap)

    Particles = []
    Running = True
    FrameCount = 0

    while Running:
        SCREEN.fill(BLACK)

        for Event in pygame.event.get():
            if Event.type == pygame.QUIT:
                Running = False

        Keys = pygame.key.get_pressed()
        KeysPressed = {
            'left': Keys[pygame.K_a],
            'right': Keys[pygame.K_d],
            'up': Keys[pygame.K_w],
            'down': Keys[pygame.K_s],
        }

        if DEV_MODE:
            if Keys[pygame.K_e]:
                if CurrentMapIndex < len(Maps) - 1:
                    CurrentMapIndex += 1
                    TileMap, PlayerPos, Inventory, Deaths, MovingObjects = ResetGameState(Maps, CurrentMapIndex, 0)
                    TotalCoins = sum(Row.count(3) for Row in TileMap)
                    pygame.time.wait(200)
            if Keys[pygame.K_q]:
                if CurrentMapIndex > 0:
                    CurrentMapIndex -= 1
                    TileMap, PlayerPos, Inventory, Deaths, MovingObjects = ResetGameState(Maps, CurrentMapIndex, 0)
                    TotalCoins = sum(Row.count(3) for Row in TileMap)
                    pygame.time.wait(200)

        TileMap = UpdateMovingObjects(TileMap, MovingObjects, FrameCount)
        PlayerPos = move_player(PlayerPos, TileMap, KeysPressed)

        PlayerX, PlayerY = int(PlayerPos[0]), int(PlayerPos[1])
        if TileMap[PlayerY][PlayerX] == 6:
            Deaths += 1
            TileMap, PlayerPos, Inventory, Deaths, MovingObjects = ResetGameState(Maps, CurrentMapIndex, Deaths)
            continue

        GameState, TileMap, Inventory = interact_with_tile(PlayerPos, TileMap, Inventory)

        if GameState == 'restart':
            Deaths += 1
            TileMap, PlayerPos, Inventory, Deaths, MovingObjects = ResetGameState(Maps, CurrentMapIndex, Deaths)
            Particles.extend(GenerateParticles(PlayerPos))
            continue

        if GameState == 'next_map':
            StarRating = CalculateStarRating(Inventory, TotalCoins, Deaths)
            DisplayMessage(SCREEN, "Stage Complete", StarRating, StarImage)

            if CurrentMapIndex < len(Maps) - 1:
                CurrentMapIndex += 1
                TileMap, PlayerPos, Inventory, Deaths, MovingObjects = ResetGameState(Maps, CurrentMapIndex, 0)
                TotalCoins = sum(Row.count(3) for Row in TileMap)
            else:
                StarRating = CalculateStarRating(Inventory, TotalCoins, Deaths)
                DisplayMessage(SCREEN, "Game Over!", StarRating, StarImage, is_game_over=True)
                WaitingForInput = True
                while WaitingForInput:
                    for Event in pygame.event.get():
                        if Event.type == pygame.QUIT:
                            WaitingForInput = False
                            Running = False
                        elif Event.type == pygame.KEYDOWN:
                            if Event.key == pygame.K_r:
                                RunPuzzleGame()
                                WaitingForInput = False
                            elif Event.key == pygame.K_q:
                                WaitingForInput = False
                                Running = False
                continue

        draw_map(SCREEN, TileMap)
        SCREEN.blit(PlayerImage, (PlayerPos[0] * TILE_SIZE + 5, PlayerPos[1] * TILE_SIZE + 5))
        RenderParticles(Particles, SCREEN)
        UpdateParticles(Particles)
        # Draw Inventory with Icons
        PaddingX = 10
        PaddingY = HEIGHT - 50
        IconSpacing = 150
        # Coins
        SCREEN.blit(CoinIcon, (PaddingX + 30, PaddingY + 5))
        CoinCountText = Font.render(f"x {Inventory['coins']}", True, YELLOW)
        SCREEN.blit(CoinCountText, (PaddingX + 80, PaddingY + 5)) # 5
        # Keys
        SCREEN.blit(KeyIcon, (PaddingX + 125 + IconSpacing, PaddingY))
        KeyCountText = Font.render(f"x {Inventory['keys']}", True, NEON_GREEN)
        SCREEN.blit(KeyCountText, (PaddingX + IconSpacing + 180, PaddingY + 5))
        # Deaths
        SCREEN.blit(SkullIcon, (PaddingX + 250 + IconSpacing * 2, PaddingY -10))
        DeathsText = Font.render(f"x {Deaths}", True, RED)
        SCREEN.blit(DeathsText, (PaddingX + IconSpacing * 2 + 300, PaddingY + 5))
        pygame.display.flip()
        Clock.tick(FPS)
        FrameCount += 1

    pygame.quit()

if __name__ == '__main__':
    RunPuzzleGame()