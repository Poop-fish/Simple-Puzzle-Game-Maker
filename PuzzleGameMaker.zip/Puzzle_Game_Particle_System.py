import random , pygame 

TILE_SIZE = 50
WIDTH, HEIGHT = 760, 460
def GenerateParticles(PlayerPos):
    Particles = []
    NumParticles = 50
   
    for _ in range(NumParticles):
        Color = (random.randint(10, 255), random.randint(50, 255), random.randint(80, 255))
        Velocity = (random.uniform(-1, 1), random.uniform(-1, 1))
        Lifetime = random.randint(20, 200)
        ParticleX = PlayerPos[0] * TILE_SIZE + TILE_SIZE // 2
        ParticleY = PlayerPos[1] * TILE_SIZE + TILE_SIZE // 2
        Particles.append(Particle(ParticleX, ParticleY, Color, Velocity, Lifetime))
    return Particles

def RenderParticles(Particles, SCREEN):
    for Particle in Particles:
        pygame.draw.circle(SCREEN, Particle.Color, (int(Particle.X), int(Particle.Y)), 3)

def UpdateParticles(Particles):
    for Particle in Particles:
        Particle.Update()
    Particles[:] = [P for P in Particles if not P.IsDead()]

class Particle:
    def __init__(self, X, Y, Color, Velocity, Lifetime):
        self.X = X
        self.Y = Y
        self.Color = Color
        self.Velocity = Velocity
        self.Lifetime = Lifetime


    def Update(self):
        self.X += self.Velocity[0]
        self.Y += self.Velocity[1]
        self.Lifetime -= 1

    def IsDead(self):
        return self.Lifetime <= 0
    
