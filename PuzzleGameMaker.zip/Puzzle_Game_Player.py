
def move_player(Player_Pos, Tile_Map, Keys_Pressed, Speed=0.5):
    Player_X, Player_Y = Player_Pos
    New_X, New_Y = Player_X, Player_Y
    
    #\\ Horizontal movement //
    if Keys_Pressed['left']:
        New_X -= Speed
    if Keys_Pressed['right']:
        New_X += Speed

    #\\ Vertical movement //
    if Keys_Pressed['up']:
        New_Y -= Speed
    if Keys_Pressed['down']:
        New_Y += Speed

    #\\ Check if the new position is valid //
    if 0 <= New_X < len(Tile_Map[0]) and 0 <= New_Y < len(Tile_Map):
        Tile = Tile_Map[int(New_Y)][int(New_X)]  #> Use integers for tile indices <
        if Tile != 1:  #> Not a wall
            Player_Pos = New_X, New_Y

    return Player_Pos

def interact_with_tile(Player_Pos, Tile_Map, Inventory):
    Player_X, Player_Y = Player_Pos
    Player_X = int(Player_X)
    Player_Y = int(Player_Y)

    Tile = Tile_Map[Player_Y][Player_X]  #\\ Ensure tile indices are integers

    if Tile == 2:  #\\ Dangerous object: Restart the game
        return 'restart', Tile_Map, Inventory
    elif Tile == 3:  # Coin
        Inventory['coins'] += 1
        Tile_Map[Player_Y][Player_X] = 0
    elif Tile == 4:  # Key
        Inventory['keys'] += 1
        Tile_Map[Player_Y][Player_X] = 0
    elif Tile == 5:  # Door
        if Inventory['keys'] > 0:  #\\ If player has a key
            Inventory['keys'] -= 1  #\\ Use the key
            Tile_Map[Player_Y][Player_X] = 0  #\\ Remove the door (open it)
            return 'next_map', Tile_Map, Inventory  #\\ Indicate the transition to the new map

    return 'continue', Tile_Map, Inventory
