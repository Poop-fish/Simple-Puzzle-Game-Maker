import pygame , random , itertools 
from Puzzle_Game_Particle_System import Particle

def DisplayMessage(SCREEN, Message, StarRating, StarImage, is_game_over=False):

    WIDTH, HEIGHT = 760, 460 # \\ 760, 460
    BLACK = ("#000000")
    WHITE = ("#e4ede4")
    NEON_GREEN = ("#07ed0b")
    YELLOW = ("#f0fc03")
    BLUE = ("#051efc")
    RED = ("#ff0000") 
    GREY = ("#545454")
    SCREEN.fill(GREY)
    
    # \\ Colors for flashing border \\
    FlashingColors = itertools.cycle([(RED), (NEON_GREEN), (BLUE), (YELLOW)])  # \\ Red, Green, Blue, Yellow \\
    CurrentColor = next(FlashingColors)
    FlashInterval = 200  # \\ Time in milliseconds between color changes \\
    LastFlashTime = pygame.time.get_ticks()
    Flashing = True
    StartTime = pygame.time.get_ticks()
    Duration = 5000  # \\ Display duration in milliseconds \\
    
    while Flashing:
        SCREEN.fill(GREY)
        # \\ Get current time \\
        CurrentTime = pygame.time.get_ticks()
        
        # \\ Change the color at each interval \\
        if CurrentTime - LastFlashTime > FlashInterval:
            CurrentColor = next(FlashingColors)
            LastFlashTime = CurrentTime
        
        #\\ Floating Particals \\ 
        if CurrentTime - StartTime > Duration:
            Flashing = False
        else:
            for i in range(100):
                x = random.randint(0, WIDTH - 1)
                y = random.randint(0, HEIGHT - 1)
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                velocity = (random.uniform(-100, 400), random.uniform(-100, 100))
                particle = Particle(x, y, color, velocity, random.randint(50, 200))
                pygame.draw.circle(SCREEN, particle.Color, (int(particle.X), int(particle.Y)), 5)
                particle.Update()
                if particle.IsDead():
                    break
        
        # \\ Main message with flashing border \\
        Font = pygame.font.Font('Assets/PixelFont1.ttf', 32)
        Text = Font.render(Message, True, NEON_GREEN)
        TextWidth, TextHeight = Text.get_size()
        BackgroundRect = pygame.Rect((WIDTH // 2 - TextWidth // 2 - 20, HEIGHT // 2 - TextHeight // 2 - 20), (TextWidth + 40, TextHeight + 40))
        
        # \\ Flashing border \\
        pygame.draw.rect(SCREEN, CurrentColor, BackgroundRect, border_radius=15, width=4)
        pygame.draw.rect(SCREEN, (0, 0, 0, 180), BackgroundRect.inflate(-8, -8), border_radius=15)
        SCREEN.blit(Text, (WIDTH // 2 - TextWidth // 2, HEIGHT // 2 - TextHeight // 2))
        
        # \\ Stars \\
        StarSpacing = 100
        for i in range(StarRating):
            SCREEN.blit(StarImage, (WIDTH // 2 - 140 + (i * StarSpacing), HEIGHT // 2 + 100))
        
        # \\ Rating text with flashing border \\
        RatingFont = pygame.font.Font('Assets/PixelFont1.ttf', 32)
        RatingText = RatingFont.render(f"Rating: {StarRating}", True, NEON_GREEN)
        RatingTextWidth, RatingTextHeight = RatingText.get_size()
        RatingRect = pygame.Rect((WIDTH // 2 - RatingTextWidth // 2 - 20, HEIGHT // 2 - 120), (RatingTextWidth + 40, RatingTextHeight + 20))
        
        pygame.draw.rect(SCREEN, CurrentColor, RatingRect, border_radius=15, width=4)
        pygame.draw.rect(SCREEN, (0, 0, 0, 180), RatingRect.inflate(-8, -8), border_radius=15)
        SCREEN.blit(RatingText, (WIDTH // 2 - RatingTextWidth // 2, HEIGHT // 2 - 110))
        
        # \\ Instructions text \\
        InstructionFont = pygame.font.Font('Assets/PixelFont1.ttf',15)
        InstructionText = InstructionFont.render("""BEWARE: Some objects will reset the game 
                and affect your rating!""", True, RED)
        InstructionTextWidth, InstructionTextHeight = InstructionText.get_size()
        InstructionRect = pygame.Rect((WIDTH // 2 - InstructionTextWidth // 2 - 20, HEIGHT // 2 - 200), (InstructionTextWidth + 40, InstructionTextHeight + 20))
        
        pygame.draw.rect(SCREEN, CurrentColor, InstructionRect, border_radius=15, width=4)
        pygame.draw.rect(SCREEN, (0, 0, 0, 180), InstructionRect.inflate(-8, -8), border_radius=15)
        SCREEN.blit(InstructionText, (WIDTH // 2 - InstructionTextWidth // 2, HEIGHT // 2 - 190))
        
        # \\ Quit/Restart options if it's game over \\
        if is_game_over:
            QuitText = InstructionFont.render("Press Q to Quit or R to Restart", True, NEON_GREEN)
            QuitTextWidth, QuitTextHeight = QuitText.get_size()
            QuitRect = pygame.Rect((WIDTH // 2 - QuitTextWidth // 2 - 20, HEIGHT // 2 + 180), (QuitTextWidth + 40, QuitTextHeight + 20))
            
            pygame.draw.rect(SCREEN, CurrentColor, QuitRect, border_radius=15, width=4)
            pygame.draw.rect(SCREEN, (0, 0, 0, 180), QuitRect.inflate(-8, -8), border_radius=15)
            SCREEN.blit(QuitText, (WIDTH // 2 - QuitTextWidth // 2, HEIGHT // 2 + 190))
        
        # \\ Update the screen \\
        pygame.display.flip()

        # \\ Exit the flashing loop after the duration \\
        if CurrentTime - StartTime > Duration:
            Flashing = False
      
      # pygame.time.wait(1000) 